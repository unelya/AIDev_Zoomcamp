"""FastMCP CLI package."""

from .cli import app
